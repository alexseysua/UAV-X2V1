init_throttle = 0;
init_aileron = 0;
init_elevator = 0;
init_rudder = 0;
init_mixture = 0;
init_run_set = 0;
init_flaps = 0;
init_gear = 0;

